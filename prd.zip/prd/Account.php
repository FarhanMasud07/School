
<?php
//echo "<pre>";print_r($GLOBALS);echo "</pre>";
session_start();

//if(isset($_SESSION["Pattern"]) && $_SESSION["Pattern"]="Pattern1234555"){
	
    //echo "Your private message : '017110000'";
    
    
if(isset($_SESSION["flag"]) )
  {
      
      $duration = $_SESSION["flag"]["duration"];
      $start = $_SESSION["flag"]["start"];
      
      if((time() - $start) > $duration)
      {
          unset($_SESSION["flag"]["duration"]);
          unset($_SESSION["flag"]["start"]);
          unset($_SESSION["flag"]);
          session_destroy();
          
      }
      else{
           $_SESSION["flag"]["start"] = time();

  ?>  
    
    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Home Page | PRD </title>
    <title>Home Page | PRD </title>


    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/nprogress.css" rel="stylesheet">
    <link href="css/custom.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../SchoolManagement/demodesign.css">
    
    
       
<style>
* {
    box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 10px;
    height: 200px; /* Should be removed. Only for demonstration */
}
   

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}
    #st{
        color: #fff;
        font-size: 20px;
       text-align: center;
        margin-top: 50px;
        margin-left: 70px;
        position: absolute;
        
        
    }
    #st:hover{
        font-size: 23px;
        color:aquamarine;
        font:timesroman;
    }
    #sa{
        color: #fff;
        font-size: 20px;
       text-align: center;
        margin-top: 50px;
        margin-left: 140px;
        position: absolute;
        
        
    }
    #sa:hover{
        font-size: 23px;
        color:cornsilk;
        font:timesroman;
    }
   
    
    #ei{
        color: #fff;
        font-size: 20px;
       text-align: center;
        margin-top: 50px;
        margin-left: 170px;
        position: absolute;
        
        
    }
    #ei:hover{
        font-size: 23px;
        color:blanchedalmond;
        font:timesroman;
    }
    #ca{
        
        
        
    }
    #ca:hover{
        
    }

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
 @media screen and (min-width: 601px) {
      .column {
        width:50%;
        
      }
}
@media screen and (max-width: 1150px) {
    .column {
        width: 100%;
        
    }
    #st{
        text-align : center;
        font-size:18px;
    }
    
}



</style>
     
    
     
    
    
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="#" class="site_title"><i class="fa fa-book"></i> <span>PRD</span></a>
                </div>

                <div class="clearfix"></div>

                <!-- menu profile quick info -->
                <div class="profile clearfix">
                    <div class="profile_pic">
                        <img src="image/pexels-photo-54278.jpeg" alt="..." class="img-circle profile_img">
                    </div>
                    <div class="profile_info">
                        <span>Welcome,</span>

                        <h2>Farhan Masud</h2>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <!-- /menu profile quick info -->

                <br/>

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">
                        <h3>General</h3>
                        <ul class="nav side-menu">
                            <li><a href="MyHome.php"><i class="fa fa-home"></i> Notice <span class="fa fa-chevron-down"></span></a>

                            
                           
                            
                            
                            <li><a href="Account.php"><i class="fa fa-bar-chart-o"></i> Account <span
                                    class="fa fa-chevron-down"></span></a>

                            </li>

                        </ul>
                    </div>


                </div>

            </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <nav>
                    <div class="nav toggle">
                         <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                        
                    </div>

                    <ul class="nav navbar-nav navbar-right">
                        <li class="">
                            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown"
                               aria-expanded="false">
                                <img src="image/pexels-photo-54278.jpeg" alt="">Farhan
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu pull-right">
                                <li><a href='logout.php'><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                            </ul>
                        </li>

                        <li role="presentation" class="dropdown">
                            <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown"
                               aria-expanded="false">
                                <i class="fa fa-envelope-o"></i>
                                <span class="badge bg-green">6</span>
                            </a>

                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- /top navigation -->

        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                


                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            
                          <form method="post">
                                    
                            <div>
                             
                            
                              <div class="row">
                                  <div class="column" id="ac" style="background-color:#005de9;border:2px solid #fff;border-radius:2%;">
                                     <a id="st" href="AccountInMonth.php">Student Monthly Fess</a>
                                    
                                  </div>
                                  <div class="column" style="background-color:#af1a3f;border:2px solid #fff;border-radius:2%;">
                                    <a id="st"  href="SignupStudent.php">New Student Admision Fees </a>
                                   
                                  </div>
                                  <div class="column" style="background-color:#008e00;border:2px solid #fff;border-radius:2%;">
                                   <a id="st"   href="Expend.php">Expense & Income</a>
                                    
                                  </div>
                                  
                                  <div class="column" id="ca" style="background-color:#005de9;border:2px solid #fff;border-radius:2%;">
                                     <a id="st" href="oldStudentAnualFees.php">Old Student Anual Fess</a>
                                    
                                  </div>
                                  
                             </div>
                              
                            
                                
                            </div>
                            
                         
                          
                    
                          
                   
                                                                           
                        </form>
                         
                    
                         
                         <br/>
                         <br/>
                         
                         
                         
             <!-- *******************  FOR INSERT *******************                        
                          
                           
       
                
                
                
            
                                
                         
                           
                    *******************  FOR DELETE ******************* --> 
                            
                            
                            
                            
             
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
        
        
       

        <!-- footer content -->
        <footer>
            <div class="pull-right">
                School Management System
            </div>
            <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
    </div>
</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- NProgress -->
<script src="js/nprogress.js"></script>

<!-- Custom Theme Scripts -->
<script src="js/custom.min.js"></script>
</body>
</html>
    
    
<?php    
    
    
      }
   
	
}
else{
	echo "Invalid user";
	header("Location:Main.php?error=invalid user");
}
?>

